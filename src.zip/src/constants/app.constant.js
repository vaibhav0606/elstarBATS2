export const APP_NAME = 'BATS'
export const PERSIST_STORE_NAME = 'admin'
export const REDIRECT_URL_KEY = '/home'
