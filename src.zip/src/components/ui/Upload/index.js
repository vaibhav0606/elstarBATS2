import Upload from './Upload'

export default Upload
