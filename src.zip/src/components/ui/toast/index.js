import toast from './toast'

export default toast
