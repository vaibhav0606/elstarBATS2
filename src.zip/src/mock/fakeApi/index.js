export { default as authFakeApi } from './authFakeApi'
