export default function isLastChild(arr, index) {
    return arr.length === index + 1
}
