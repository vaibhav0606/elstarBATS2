import React from 'react'

/** Example purpose only */
const GroupSingleMenuItemView = () => {
    return <div>GroupSingleMenuItemView</div>
}

export default GroupSingleMenuItemView
