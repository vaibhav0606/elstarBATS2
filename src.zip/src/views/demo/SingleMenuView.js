import React from 'react'

/** Example purpose only */
const SingleMenuView = () => {
    return <div>Single Menu View</div>
}

export default SingleMenuView
