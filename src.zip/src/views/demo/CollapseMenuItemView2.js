import React from 'react'

/** Example purpose only */
const CollapseMenuItemView2 = () => {
    return <div>CollapseMenuItemView2</div>
}

export default CollapseMenuItemView2
