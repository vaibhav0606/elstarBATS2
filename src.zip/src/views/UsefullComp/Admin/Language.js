const language = [
    {
        asterisk: true,
        lable: 'Language Name',
        placeholder: 'Language Name',
        name: 'LanguageName',
        type: 'text',
        width: '50%',
    },
    // {
    //     cats: 'text',
    //     asterisk: true,
    //     lable: 'Address',
    //     placeholder: 'Corp Address',
    //     name: 'CorpAddress',
    //     type: 'text',
    //     width: '50%',
    // },
    // {
    //     cats: 'text',
    //     asterisk: true,
    //     lable: 'Contact Person',
    //     placeholder: 'Contact Person',
    //     name: 'ContactPerson',
    //     type: 'text',
    //     width: '50%',
    // },
]
export default language
