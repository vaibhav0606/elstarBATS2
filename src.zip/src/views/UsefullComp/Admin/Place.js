const channel = [
    {
        asterisk: true,
        lable: 'Place Name',
        placeholder: 'Place Name',
        name: 'PlaceName',
        type: 'text',
        width: '50%',
    },
    {
        asterisk: true,
        lable: 'ShortName',
        placeholder: 'ShortName',
        name: 'ShortName',
        type: 'text',
        width: '50%',
    },
    // {
    //     asterisk: true,
    //     lable: 'Zone Code',
    //     placeholder: 'Zone Code',
    //     name: 'ZoneCode',
    //     type: 'text',
    //     width: '50%',
    // },
    // {
    //     asterisk: true,
    //     lable: 'State Code',
    //     placeholder: 'State Code',
    //     name: 'StateCode',
    //     type: 'text',
    //     width: '50%',
    // },
    // {
    //     asterisk: true,
    //     lable: 'CountryCode',
    //     placeholder: 'CountryCode',
    //     name: 'CountryCode',
    //     type: 'text',
    //     width: '50%',
    // },
]
export default channel
