const language = [
    {
        asterisk: true,
        lable: 'Designation Name',
        placeholder: 'Designation Name',
        name: 'DesignationName',
        type: 'text',
        width: '50%',
    },
    {
        asterisk: true,
        lable: 'Short Name',
        placeholder: 'Short Name',
        name: 'ShortName',
        type: 'text',
        width: '50%',
    },
]
export default language
