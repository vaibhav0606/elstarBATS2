const language = [
    {
        asterisk: true,
        lable: 'Currency Name',
        placeholder: 'Currency Name',
        name: 'CurrencyName',
        type: 'text',
        width: '50%',
    },
    {
        asterisk: true,
        lable: 'Currency Symbol',
        placeholder: 'Currency Symbol',
        name: 'CurrencySymbol',
        type: 'text',
        width: '50%',
    },
    {
        asterisk: true,
        lable: 'Short Name',
        placeholder: 'Short Name',
        name: 'ShortName',
        type: 'text',
        width: '50%',
    },
]
export default language
