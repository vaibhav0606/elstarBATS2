const module = [
    {
        asterisk: true,
        lable: 'SubModule Name',
        placeholder: 'SubModule Name',
        name: 'SubModuleName',
        type: 'text',
        width: '50%',
    },
    {
        asterisk: true,
        lable: 'Index Number',
        placeholder: 'Index Number',
        name: 'IndexNum',
        type: 'text',
        width: '50%',
    },
    // {
    //     cats: 'text',
    //     asterisk: true,
    //     lable: 'Address',
    //     placeholder: 'Corp Address',
    //     name: 'CorpAddress',
    //     type: 'text',
    //     width: '50%',
    // },
    // {
    //     cats: 'text',
    //     asterisk: true,
    //     lable: 'Contact Person',
    //     placeholder: 'Contact Person',
    //     name: 'ContactPerson',
    //     type: 'text',
    //     width: '50%',
    // },
]
export default module
